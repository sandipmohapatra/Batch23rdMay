import { Component, OnInit, InjectionToken, Inject } from '@angular/core';
import { Book } from './book';

const Angular_Book = new Book('Learn Angular', 'Version 7');
export const Angular_Message = new InjectionToken<string>('Learn Angular 6!'); 

@Component({
    selector: 'book',
    providers: [ 
	    { provide: Book, useValue: Angular_Book },
		{ provide: Angular_Message, useValue: 'Learn Angular 7 step by step' }
	],     
    template: `
	     <p>Book Name: <b>{{book.bookname}}</b> </p>
		 <p>Version: <b>{{book.version}}</b></p>
		 <p>Message: <b>{{message}}</b> </p>
	`
})
export class BookComponent implements OnInit {
	constructor(private book: Book, 
	            @Inject(Angular_Message) private message: string) { }
	
	ngOnInit() {
	}
}
 
