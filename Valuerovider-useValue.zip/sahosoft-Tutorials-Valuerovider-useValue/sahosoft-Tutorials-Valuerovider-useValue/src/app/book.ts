export class Book {
	constructor(public bookname: string, public version: string){}
}