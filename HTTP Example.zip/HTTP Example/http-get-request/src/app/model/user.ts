export interface User {
    avatar: string;
    email: string;
    first_name: string;
    id: Number;
    last_name: string;
}